import json
import sys
from pathlib import Path

import numpy as np
import trimesh

from generate import box, colored, cylinder, rgba


def build_motor_v2(cfg):
    d, detail = cfg["dimensions_m"], cfg["detail"]
    c = {k: rgba(v) for k, v in cfg["colors"].items()}
    length, radius = d["body_length"], d["body_radius"]
    base_z = d["foot_height"]
    axis_z = base_z + radius * 1.04
    pieces = []

    # Cuerpo, tapas y ventilador: silueta escalonada más cercana a un motor IEC.
    pieces += [
        cylinder(radius, length * .78, [0, 0, axis_z], c["body"], detail["radial_sections"]),
        cylinder(radius * 1.08, length * .10, [length * .44, 0, axis_z], c["body_light"], detail["radial_sections"]),
        cylinder(radius * 1.08, length * .10, [-length * .44, 0, axis_z], c["body_light"], detail["radial_sections"]),
        cylinder(radius * 1.13, length * .07, [-length * .525, 0, axis_z], c["dark"], detail["radial_sections"]),
        cylinder(radius * .94, length * .025, [-length * .575, 0, axis_z], c["dark"], detail["radial_sections"]),
        cylinder(d["shaft_radius"] * 1.16, d["shaft_length"] * .35, [length * .555, 0, axis_z], c["dark"], 32),
        cylinder(d["shaft_radius"], d["shaft_length"], [length * .72, 0, axis_z], c["metal"], 32),
    ]

    # Aletas longitudinales más finas y legibles.
    for angle in np.linspace(0, 2 * np.pi, detail["cooling_fins"], endpoint=False):
        y = np.cos(angle) * radius * 1.035
        z = axis_z + np.sin(angle) * radius * 1.035
        fin = box([length * .70, radius * .040, radius * .115], [0, y, z], c["body_light"])
        fin.apply_transform(trimesh.transformations.rotation_matrix(angle, [1, 0, 0], point=[0, y, z]))
        pieces.append(fin)

    # Caja de conexiones con tapa contrastada y prensaestopas lateral.
    terminal_z = axis_z + radius * 1.22
    pieces += [
        box([length * .32, radius * .88, radius * .42], [-length * .02, 0, terminal_z], c["body"]),
        box([length * .35, radius * .94, radius * .055], [-length * .02, 0, terminal_z + radius * .235], c["dark"]),
        cylinder(radius * .12, radius * .22, [-length * .02, radius * .54, terminal_z], c["dark"], 24),
    ]
    # El prensaestopas anterior se rota para salir por Y.
    pieces[-1].apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0], point=[-length * .02, radius * .54, terminal_z]))

    # Placa de identificación AssetPlan en dorado apagado.
    pieces.append(box([length * .22, radius * .018, radius * .34], [length * .03, -radius * 1.035, axis_z + radius * .05], c["accent"]))

    # Base y cuatro patas diferenciadas.
    pieces.append(box([length * 1.18, radius * 1.72, d["foot_height"] * .22], [0, 0, d["foot_height"] * .11], c["dark"]))
    for x in (-length * .30, length * .30):
        for y in (-radius * .66, radius * .66):
            pieces.append(box([length * .25, radius * .34, d["foot_height"]], [x, y, d["foot_height"] / 2], c["dark"]))
            # Cabeza de perno visible.
            bolt = trimesh.creation.cylinder(radius=radius * .055, height=d["foot_height"] * .10, sections=16)
            bolt.apply_translation([x, y, d["foot_height"] * 1.05])
            pieces.append(colored(bolt, c["metal"]))

    # Rejilla trasera radial simplificada.
    rear_x = -length * .615
    for a in np.linspace(0, 2 * np.pi, 8, endpoint=False):
        y, z = np.cos(a) * radius * .60, axis_z + np.sin(a) * radius * .60
        pieces.append(cylinder(radius * .018, radius * 1.20, [rear_x, y / 2, axis_z + (z - axis_z) / 2], c["metal"], 12))
        pieces[-1].apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0], point=[rear_x, y / 2, axis_z + (z - axis_z) / 2]))

    scale = detail["presentation_scale"]
    scene = trimesh.Scene()
    for i, mesh in enumerate(pieces):
        mesh.apply_scale(scale)
        scene.add_geometry(mesh, node_name=f"motor_v2_part_{i:03d}", geom_name=f"motor_v2_part_{i:03d}")
    return scene


def main(config_path):
    config_file = Path(config_path).resolve()
    cfg = json.loads(config_file.read_text(encoding="utf-8"))
    if cfg.get("family") != "electric_motor_v2":
        raise ValueError("Se esperaba family=electric_motor_v2")
    output = config_file.parent.parent / cfg["output"]
    output.parent.mkdir(parents=True, exist_ok=True)
    scene = build_motor_v2(cfg)
    output.write_bytes(scene.export(file_type="glb"))
    triangles = sum(len(g.faces) for g in scene.geometry.values())
    print(f"OK {output} | {output.stat().st_size} bytes | {triangles} triangles")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) == 2 else "configs/motor_iec_132_v2.json")
