import json
import sys
from pathlib import Path

import numpy as np
import trimesh

from generate import box, colored, cylinder, rgba
from generate_pump import z_cylinder


def frustum_z(radius_bottom, radius_top, height, center, color, sections=48):
    angles = np.linspace(0, 2 * np.pi, sections, endpoint=False)
    zb, zt = -height / 2, height / 2
    vertices = []
    for z, radius in ((zb, radius_bottom), (zt, radius_top)):
        vertices.extend([[radius * np.cos(a), radius * np.sin(a), z] for a in angles])
    faces = []
    for i in range(sections):
        n = (i + 1) % sections
        faces.extend([[i, n, sections + n], [i, sections + n, sections + i]])
    vertices.extend([[0, 0, zb], [0, 0, zt]])
    bc, tc = 2 * sections, 2 * sections + 1
    for i in range(sections):
        n = (i + 1) % sections
        faces.extend([[bc, n, i], [tc, sections + i, sections + n]])
    mesh = trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=False)
    mesh.apply_translation(center)
    return colored(mesh, color)


def build_gate_valve(cfg):
    detail = cfg["detail"]
    c = {k: rgba(v) for k, v in cfg["colors"].items()}
    sec = detail["radial_sections"]
    axis_z = .30
    pieces = []

    # Paso horizontal inequívoco y bridas dominantes.
    pieces += [
        cylinder(.105, .82, [0, 0, axis_z], c["body"], sec),
        cylinder(.185, .055, [-.435, 0, axis_z], c["dark"], sec),
        cylinder(.185, .055, [.435, 0, axis_z], c["dark"], sec),
        cylinder(.118, .022, [-.475, 0, axis_z], c["metal"], sec),
        cylinder(.118, .022, [.475, 0, axis_z], c["metal"], sec),
    ]

    # Cuerpo compacto de compuerta: cámara ancha con caras laterales planas.
    pieces += [
        cylinder(.215, .30, [0, 0, axis_z], c["body_light"], sec),
        cylinder(.170, .026, [-.165, 0, axis_z], c["body"], sec),
        cylinder(.170, .026, [.165, 0, axis_z], c["body"], sec),
        box([.29, .25, .12], [0, 0, .405], c["body_light"]),
    ]

    # Bonnet troncocónico, tapa y cuello de prensaestopas.
    pieces += [
        z_cylinder(.180, .050, [0, 0, .515], c["dark"], sec),
        frustum_z(.155, .095, .20, [0, 0, .64], c["body"], sec),
        z_cylinder(.115, .045, [0, 0, .7625], c["dark"], sec),
        z_cylinder(.075, .065, [0, 0, .8175], c["body_light"], sec),
    ]

    # Yugo alto con columnas separadas en X para que se lean en la vista frontal.
    for x in (-.105, .105):
        pieces.append(box([.045, .065, .34], [x, 0, .98], c["body"]))
    pieces += [
        box([.27, .09, .055], [0, 0, 1.135], c["body"]),
        z_cylinder(.040, .50, [0, 0, 1.01], c["metal"], 24),
        z_cylinder(.068, .055, [0, 0, 1.17], c["accent"], 24),
    ]

    # Volante superior horizontal, con radios claros y cubo central.
    wheel_z = 1.245
    wheel = trimesh.creation.torus(major_radius=.235, minor_radius=.024, major_sections=sec, minor_sections=12)
    wheel.apply_translation([0, 0, wheel_z])
    pieces.append(colored(wheel, c["dark"]))
    pieces.append(z_cylinder(.065, .060, [0, 0, wheel_z], c["accent"], 24))
    for angle in np.linspace(0, 2 * np.pi, detail["handwheel_spokes"], endpoint=False):
        spoke = box([.205, .022, .018], [.132, 0, wheel_z], c["dark"])
        spoke.apply_transform(trimesh.transformations.rotation_matrix(angle, [0, 0, 1], point=[0, 0, wheel_z]))
        pieces.append(spoke)

    # Pernos y placa: detalle visual sin competir con la silueta.
    for x in (-.435, .435):
        for angle in np.linspace(0, 2 * np.pi, 6, endpoint=False):
            y = np.cos(angle) * .145
            z = axis_z + np.sin(angle) * .145
            pieces.append(cylinder(.011, .070, [x, y, z], c["accent"], 12))
    pieces.append(box([.16, .012, .065], [.03, -.218, axis_z + .01], c["accent"]))

    scale = detail["presentation_scale"]
    scene = trimesh.Scene()
    for i, mesh in enumerate(pieces):
        mesh.apply_scale(scale)
        scene.add_geometry(mesh, node_name=f"valve_m041_part_{i:03d}", geom_name=f"valve_m041_part_{i:03d}")
    return scene


def main(config_path):
    config_file = Path(config_path).resolve()
    cfg = json.loads(config_file.read_text(encoding="utf-8"))
    if cfg.get("family") != "gate_valve_handwheel_m041":
        raise ValueError("Se esperaba family=gate_valve_handwheel_m041")
    output = config_file.parent.parent / cfg["output"]
    output.parent.mkdir(parents=True, exist_ok=True)
    scene = build_gate_valve(cfg)
    output.write_bytes(scene.export(file_type="glb"))
    triangles = sum(len(g.faces) for g in scene.geometry.values())
    print(f"OK {output} | {output.stat().st_size} bytes | {triangles} triangles")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) == 2 else "configs/gate_valve_handwheel_m041.json")
