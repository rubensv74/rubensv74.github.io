import json
import sys
from pathlib import Path

import numpy as np
import trimesh

from generate import box, colored, cylinder, rgba


def z_cylinder(radius, height, center, color, sections=40):
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    mesh.apply_translation(center)
    return colored(mesh, color)


def sphere(scale, center, color, subdivisions=2):
    mesh = trimesh.creation.icosphere(subdivisions=subdivisions, radius=1.0)
    mesh.apply_scale(scale)
    mesh.apply_translation(center)
    return colored(mesh, color)


def build_pump(cfg):
    detail = cfg["detail"]
    c = {k: rgba(v) for k, v in cfg["colors"].items()}
    sec = detail["radial_sections"]
    pieces = []

    # Bancada común del conjunto bomba-motor.
    pieces += [
        box([1.34, .48, .045], [.06, 0, .0225], c["dark"]),
        box([1.18, .38, .055], [.06, 0, .0725], c["metal"]),
    ]
    for x in (-.50, .52):
        for y in (-.18, .18):
            pieces.append(z_cylinder(.022, .018, [x, y, .108], c["accent"], 16))

    # Voluta de la bomba: cuerpo asimétrico, tapa y anillo frontal.
    pump_x, axis_z = -.38, .35
    pieces += [
        sphere([.19, .12, .205], [pump_x, 0, axis_z], c["pump"], 3),
        cylinder(.205, .085, [pump_x - .035, 0, axis_z], c["pump_light"], sec),
        cylinder(.145, .018, [pump_x - .088, 0, axis_z], c["dark"], sec),
        cylinder(.105, .12, [pump_x - .14, 0, axis_z], c["pump"], sec),
        cylinder(.142, .028, [pump_x - .215, 0, axis_z], c["dark"], sec),
        cylinder(.108, .016, [pump_x - .237, 0, axis_z], c["metal"], sec),
    ]

    # Descarga vertical con cuello y brida superior.
    pieces += [
        z_cylinder(.082, .22, [pump_x + .035, 0, .555], c["pump"], sec),
        z_cylinder(.128, .035, [pump_x + .035, 0, .6825], c["dark"], sec),
        z_cylinder(.087, .018, [pump_x + .035, 0, .709], c["metal"], sec),
    ]

    # Soporte de rodamientos, eje y acoplamiento protegido.
    pieces += [
        cylinder(.090, .24, [pump_x + .235, 0, axis_z], c["pump_light"], sec),
        cylinder(.035, .13, [pump_x + .415, 0, axis_z], c["metal"], 24),
        box([.24, .24, .19], [pump_x + .47, 0, axis_z], c["accent"]),
        box([.19, .245, .018], [pump_x + .47, 0, axis_z + .104], c["dark"]),
    ]

    # Motor de accionamiento simplificado pero coherente con M02.
    motor_x, motor_r, motor_len = .49, .135, .48
    pieces += [
        cylinder(motor_r, motor_len, [motor_x, 0, axis_z], c["motor"], sec),
        cylinder(motor_r * 1.08, .045, [motor_x + motor_len / 2, 0, axis_z], c["pump_light"], sec),
        cylinder(motor_r * 1.10, .060, [motor_x - motor_len / 2, 0, axis_z], c["dark"], sec),
        box([.20, .18, .11], [motor_x, 0, axis_z + motor_r * 1.17], c["motor"]),
        box([.22, .20, .018], [motor_x, 0, axis_z + motor_r * 1.61], c["dark"]),
        box([.16, .012, .075], [motor_x + .02, -.137, axis_z + .01], c["accent"]),
    ]

    # Aletas longitudinales del motor.
    for angle in np.linspace(0, 2 * np.pi, 14, endpoint=False):
        y = np.cos(angle) * motor_r * 1.025
        z = axis_z + np.sin(angle) * motor_r * 1.025
        fin = box([motor_len * .72, motor_r * .035, motor_r * .10], [motor_x, y, z], c["pump_light"])
        fin.apply_transform(trimesh.transformations.rotation_matrix(angle, [1, 0, 0], point=[motor_x, y, z]))
        pieces.append(fin)

    # Pies de bomba y motor.
    for x, width in ((pump_x, .28), (motor_x - .13, .18), (motor_x + .13, .18)):
        pieces.append(box([width, .31, .085], [x, 0, .15], c["dark"]))

    scale = detail["presentation_scale"]
    scene = trimesh.Scene()
    for i, mesh in enumerate(pieces):
        mesh.apply_scale(scale)
        scene.add_geometry(mesh, node_name=f"pump_m03_part_{i:03d}", geom_name=f"pump_m03_part_{i:03d}")
    return scene


def main(config_path):
    config_file = Path(config_path).resolve()
    cfg = json.loads(config_file.read_text(encoding="utf-8"))
    if cfg.get("family") != "centrifugal_pump_horizontal":
        raise ValueError("Se esperaba family=centrifugal_pump_horizontal")
    output = config_file.parent.parent / cfg["output"]
    output.parent.mkdir(parents=True, exist_ok=True)
    scene = build_pump(cfg)
    output.write_bytes(scene.export(file_type="glb"))
    triangles = sum(len(g.faces) for g in scene.geometry.values())
    print(f"OK {output} | {output.stat().st_size} bytes | {triangles} triangles")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) == 2 else "configs/pump_centrifugal_horizontal.json")
