import json
import sys
from pathlib import Path

import numpy as np
import trimesh

from generate import box, colored, cylinder, rgba
from generate_pump import sphere, z_cylinder


def build_gate_valve(cfg):
    detail = cfg["detail"]
    c = {k: rgba(v) for k, v in cfg["colors"].items()}
    sec = detail["radial_sections"]
    axis_z = .30
    pieces = []

    # Paso de tubería, cuerpo de válvula y bridas extremas.
    pieces += [
        cylinder(.105, .72, [0, 0, axis_z], c["body"], sec),
        sphere([.235, .17, .225], [0, 0, axis_z], c["body_light"], 3),
        cylinder(.165, .050, [-.385, 0, axis_z], c["dark"], sec),
        cylinder(.165, .050, [.385, 0, axis_z], c["dark"], sec),
        cylinder(.115, .030, [-.425, 0, axis_z], c["metal"], sec),
        cylinder(.115, .030, [.425, 0, axis_z], c["metal"], sec),
    ]

    # Cuello, bonnet y prensaestopas.
    pieces += [
        z_cylinder(.145, .12, [0, 0, .49], c["body"], sec),
        z_cylinder(.185, .055, [0, 0, .585], c["dark"], sec),
        z_cylinder(.135, .12, [0, 0, .6725], c["body_light"], sec),
        z_cylinder(.105, .045, [0, 0, .755], c["dark"], sec),
        z_cylinder(.035, .43, [0, 0, .955], c["metal"], 24),
    ]

    # Yugo abierto: dos columnas y travesaño superior.
    for y in (-.095, .095):
        pieces.append(box([.055, .055, .33], [0, y, .925], c["body"]));
    pieces += [
        box([.11, .26, .055], [0, 0, 1.075], c["body"]),
        z_cylinder(.060, .055, [0, 0, 1.11], c["accent"], 24),
    ]

    # Volante toroidal horizontal y cubo central.
    wheel_z = 1.19
    wheel = trimesh.creation.torus(major_radius=.205, minor_radius=.022, major_sections=sec, minor_sections=12)
    wheel.apply_translation([0, 0, wheel_z])
    pieces.append(colored(wheel, c["dark"]))
    pieces.append(z_cylinder(.060, .055, [0, 0, wheel_z], c["accent"], 24))

    # Radios del volante.
    for angle in np.linspace(0, 2 * np.pi, detail["handwheel_spokes"], endpoint=False):
        spoke = box([.175, .024, .018], [.112, 0, wheel_z], c["dark"])
        spoke.apply_transform(trimesh.transformations.rotation_matrix(angle, [0, 0, 1], point=[0, 0, wheel_z]))
        pieces.append(spoke)

    # Pernos de las bridas, visibles en la vista oblicua.
    for x in (-.385, .385):
        for angle in np.linspace(0, 2 * np.pi, 6, endpoint=False):
            y = np.cos(angle) * .130
            z = axis_z + np.sin(angle) * .130
            bolt = cylinder(.012, .070, [x, y, z], c["accent"], 12)
            pieces.append(bolt)

    # Placa de identificación frontal.
    pieces.append(box([.18, .012, .075], [.02, -.172, axis_z + .02], c["accent"]))

    scale = detail["presentation_scale"]
    scene = trimesh.Scene()
    for i, mesh in enumerate(pieces):
        mesh.apply_scale(scale)
        scene.add_geometry(mesh, node_name=f"valve_m04_part_{i:03d}", geom_name=f"valve_m04_part_{i:03d}")
    return scene


def main(config_path):
    config_file = Path(config_path).resolve()
    cfg = json.loads(config_file.read_text(encoding="utf-8"))
    if cfg.get("family") != "gate_valve_handwheel":
        raise ValueError("Se esperaba family=gate_valve_handwheel")
    output = config_file.parent.parent / cfg["output"]
    output.parent.mkdir(parents=True, exist_ok=True)
    scene = build_gate_valve(cfg)
    output.write_bytes(scene.export(file_type="glb"))
    triangles = sum(len(g.faces) for g in scene.geometry.values())
    print(f"OK {output} | {output.stat().st_size} bytes | {triangles} triangles")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) == 2 else "configs/gate_valve_handwheel.json")
