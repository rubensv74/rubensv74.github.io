import json
import sys
from pathlib import Path

import numpy as np
import trimesh


def rgba(value: str, alpha: int = 255):
    value = value.lstrip("#")
    return [int(value[i:i + 2], 16) for i in (0, 2, 4)] + [alpha]


def colored(mesh, color):
    mesh.visual.face_colors = np.tile(np.array(color, dtype=np.uint8), (len(mesh.faces), 1))
    return mesh


def box(extents, center, color):
    mesh = trimesh.creation.box(extents=extents)
    mesh.apply_translation(center)
    return colored(mesh, color)


def cylinder(radius, height, center, color, sections=32):
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    # trimesh crea el cilindro sobre Z; el motor usa X como eje longitudinal.
    mesh.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
    mesh.apply_translation(center)
    return colored(mesh, color)


def build_motor(cfg):
    d = cfg["dimensions_m"]
    detail = cfg["detail"]
    colors = {k: rgba(v) for k, v in cfg["colors"].items()}
    length, radius = d["body_length"], d["body_radius"]
    z_axis = d["foot_height"] + radius
    pieces = []

    pieces.append(cylinder(radius, length, [0, 0, z_axis], colors["body"], detail["radial_sections"]))
    pieces.append(cylinder(radius * 1.04, length * 0.075, [-length * .535, 0, z_axis], colors["dark"], detail["radial_sections"]))
    pieces.append(cylinder(radius * 1.07, length * 0.06, [length * .53, 0, z_axis], colors["body"], detail["radial_sections"]))
    pieces.append(cylinder(d["shaft_radius"], d["shaft_length"], [length / 2 + d["shaft_length"] / 2, 0, z_axis], colors["metal"], 24))

    # Aletas longitudinales simplificadas: repetición radial de perfiles finos.
    for angle in np.linspace(0, 2 * np.pi, detail["cooling_fins"], endpoint=False):
        y = np.cos(angle) * radius * 1.02
        z = z_axis + np.sin(angle) * radius * 1.02
        fin = box([length * .82, radius * .055, radius * .10], [0, y, z], colors["body"])
        fin.apply_transform(trimesh.transformations.rotation_matrix(angle, [1, 0, 0], point=[0, y, z]))
        pieces.append(fin)

    # Caja de bornes y tapa.
    pieces.append(box([length * .30, radius * .82, radius * .42], [-length * .04, 0, z_axis + radius * 1.16], colors["body"]))
    pieces.append(box([length * .32, radius * .86, radius * .06], [-length * .04, 0, z_axis + radius * 1.40], colors["dark"]))

    # Dos patas con zapata, manteniendo la base en Z=0.
    for x in (-length * .27, length * .27):
        pieces.append(box([d["foot_length"] * .30, radius * 1.45, d["foot_height"]], [x, 0, d["foot_height"] / 2], colors["dark"]))
        pieces.append(box([d["foot_length"], d["foot_width"], d["foot_height"] * .35], [x, radius * .72, d["foot_height"] * .175], colors["dark"]))
        pieces.append(box([d["foot_length"], d["foot_width"], d["foot_height"] * .35], [x, -radius * .72, d["foot_height"] * .175], colors["dark"]))

    scene = trimesh.Scene()
    for index, mesh in enumerate(pieces):
        scene.add_geometry(mesh, node_name=f"motor_part_{index:03d}", geom_name=f"motor_part_{index:03d}")
    return scene


def main(config_path):
    config_file = Path(config_path).resolve()
    cfg = json.loads(config_file.read_text(encoding="utf-8"))
    if cfg.get("family") != "electric_motor":
        raise ValueError("MVP 0.1 solo admite family=electric_motor")
    output = config_file.parent.parent / cfg["output"]
    output.parent.mkdir(parents=True, exist_ok=True)
    scene = build_motor(cfg)
    output.write_bytes(scene.export(file_type="glb"))
    triangles = sum(len(g.faces) for g in scene.geometry.values())
    print(f"OK {output} | {output.stat().st_size} bytes | {triangles} triangles")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Uso: python generate.py configs/modelo.json")
    main(sys.argv[1])
