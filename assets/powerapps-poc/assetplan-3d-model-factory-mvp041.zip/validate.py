import json
import struct
import sys
from pathlib import Path

import trimesh


def glb_json(path):
    raw = path.read_bytes()
    if raw[:4] != b"glTF":
        raise ValueError("No es un GLB válido")
    _, version, _ = struct.unpack_from("<4sII", raw, 0)
    chunk_length, chunk_type = struct.unpack_from("<II", raw, 12)
    if chunk_type != 0x4E4F534A:
        raise ValueError("El primer bloque GLB no contiene JSON")
    return version, json.loads(raw[20:20 + chunk_length].decode("utf-8").rstrip(" \x00"))


def main(filename):
    path = Path(filename)
    version, doc = glb_json(path)
    scene = trimesh.load(path, force="scene")
    triangles = sum(len(g.faces) for g in scene.geometry.values())
    external = [b.get("uri") for b in doc.get("buffers", []) if b.get("uri")]
    external += [i.get("uri") for i in doc.get("images", []) if i.get("uri")]
    checks = {
        "glb_version_2": version == 2,
        "has_geometry": triangles > 0,
        "no_external_resources": not external,
        "under_250kb": path.stat().st_size < 250_000,
        "under_15000_triangles": triangles < 15_000
    }
    report = {"file": str(path), "bytes": path.stat().st_size, "triangles": triangles, "geometries": len(scene.geometry), "checks": checks}
    print(json.dumps(report, indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Uso: python validate.py output/modelo.glb")
    main(sys.argv[1])
