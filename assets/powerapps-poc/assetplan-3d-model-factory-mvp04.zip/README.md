# AssetPlan 3D Model Factory — MVP 0.1

Factoría paramétrica para producir modelos industriales `.glb` ligeros y coherentes, pensados para el control **View in 3D** de Power Apps.

## Qué incluye

- Generador inicial de motores eléctricos IEC simplificados.
- Parámetros de dimensiones, color, aletas, patas y caja de bornes.
- Materiales embebidos: el GLB no necesita texturas externas.
- Validador de tamaño, triángulos, geometrías y recursos externos.
- Configuración de ejemplo y un GLB generado.

## Uso

```bash
python -m pip install -r requirements.txt
python generate.py configs/motor_iec_132.json
python validate.py output/ap-motor-iec132.glb
```

Motor visual V2:

```bash
python generate_v2.py configs/motor_iec_132_v2.json
python validate.py output/ap-motor-iec132-v2.glb
```

Bomba centrífuga horizontal M03:

```bash
python generate_pump.py configs/pump_centrifugal_horizontal.json
python validate.py output/ap-pump-centrifugal-horizontal-m03.glb
```

Válvula de compuerta con volante M04:

```bash
python generate_valve.py configs/gate_valve_handwheel.json
python validate.py output/ap-valve-gate-handwheel-m04.glb
```

El archivo resultante estará en `output/`. Para usarlo en Power Apps, publícalo en una URL HTTPS que devuelva directamente el binario `.glb`; no debe ser una página de previsualización.

## Contrato del MVP

- Unidades internas: metros.
- Eje longitudinal del equipo: X.
- Suelo: Z = 0.
- Origen: centro aproximado del cuerpo.
- Sin Draco y sin archivos de textura externos.
- Objetivo recomendado: menos de 250.000 bytes y 15.000 triángulos.

## Siguiente ampliación

La arquitectura deja preparado el crecimiento por familias. El orden recomendado es: bomba centrífuga, válvula, recipiente vertical, intercambiador y compresor. No conviene construir muchas familias antes de aprobar un lenguaje visual común con 2–3 modelos piloto.
